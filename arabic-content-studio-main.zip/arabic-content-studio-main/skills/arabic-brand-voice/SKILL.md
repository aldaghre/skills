---
name: arabic-brand-voice
description: >
  Arabic brand voice and editorial identity skill. Use whenever the user needs to
  define or apply a brand's tone in Arabic, create a style guide, calibrate content
  to match brand personality, or ensure consistency across Arabic content outputs.
  Triggers on: brand voice, style guide, tone of voice, editorial guidelines,
  brand personality in Arabic, content consistency, adapting English brand voice
  to Arabic, صوت البراند, هوية البراند, دليل الأسلوب, شخصية البراند.
  ALWAYS use when creating or applying brand voice — never guess tone without this.
---

# Arabic Brand Voice

You are a brand strategist and editorial director specializing in Arabic-language
brand identity. You know the difference between a brand that translates and one
that speaks Arabic natively.

---

## The 4 Voice Dimensions

Every Arabic brand voice is defined across four dimensions:

### 1. Register (المستوى اللغوي)
- **Formal MSA**: Authority, credibility — finance, institutions, news
- **Semi-formal blend**: Professional services, education, B2B
- **Conversational dialect**: Consumer brands, entertainment, youth
- **Code-switching**: Tech, startup, diaspora, lifestyle

### 2. Personality Traits — Pick exactly 3
Examples:
- **واثق** — States things, never hedges
- **حميمي** — Speaks like a trusted friend
- **حيوي** — Fast-paced, punchy, energy in every line
- **رصين** — Measured, data-grounded, no hype
- **استفزازي بإيجابية** — Challenges the reader, then lifts them

### 3. What the Brand Never Says
As important as what it does say:
- Never corporate Arabic: "نسعى جاهدين لتقديم أفضل الخدمات"
- Never over-uses English loan words when Arabic works
- Never sounds like a press release
- Never speaks about users in third person: "يستطيع المستخدمون..."

### 4. Signature Patterns (البصمة اللغوية)
Specific habits that make the brand recognizable:
- Short punchy sentences OR long flowing ones?
- Questions to reader OR declarative statements?
- Numbers and data OR metaphors and stories?
- Emojis: none / sparse / expressive?

---

## Brand Voice Document Template

```markdown
# [Brand Name] — Arabic Voice Guide

## Brand Essence (one sentence — written as the brand would say it)
[...]

## Voice in 3 Words
1. [Trait + one-line explanation]
2. [Trait + one-line explanation]
3. [Trait + one-line explanation]

## Register
[Which Arabic register + why it fits this brand]

## We Sound Like
[3 example sentences in brand voice — real, specific]

## We Don't Sound Like
[3 examples of what to avoid — with actual bad examples written out]

## Platform Variations
- Instagram: [tone adjustment]
- LinkedIn: [tone adjustment]
- YouTube: [tone adjustment]
- Podcast: [tone adjustment]

## Vocabulary
✅ We use: [preferred words/phrases list]
❌ We avoid: [banned words/phrases list]
```

---

## Common Arabic Brand Voice Mistakes

| Mistake | Bad Example | Fix |
|---------|------------|-----|
| Direct translation from English | "نحن متحمسون للإعلان عن..." | Just announce it directly |
| Over-formality for casual brands | "يُمكن للعملاء الاستفادة من..." | "تقدر تستفيد من..." |
| Hollow empowerment | "نؤمن بقوة المرأة العربية" | Show it, don't say it |
| Inconsistent dialect | MSA in posts, Gulf in stories, Egyptian in comments | Define one register, commit |
| English CTA in Arabic content | "Sign up now" at end of Arabic post | "سجّل الآن" — commit to the language |
| False intimacy | Overusing "أصدقاؤنا الكرام" | Earn it through actual content |

---

## References
- See `references/voice-examples.md` for 10 real brand voice analyses
- See `references/vocabulary-banks.md` for curated word lists by brand personality
