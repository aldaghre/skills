# Platform Formats — Arabic Content Specs

## Instagram

| Format | Length | Notes |
|--------|--------|-------|
| Caption | 2,200 chars max | First 125 visible — hook critical |
| Reel | 15s–90s optimal | 30-60s highest completion rate |
| Carousel | 3-10 slides | 7 slides = max engagement historically |
| Stories | 15s per slide | Text-heavy Stories underperform — visual first |

## TikTok

| Format | Length | Notes |
|--------|--------|-------|
| Short | 15-30s | Entertainment, trends |
| Standard | 30-60s | Educational, storytelling |
| Long | 1-3 min | Only if hook is exceptional |
| Max | 10 min | Avoid unless established audience |

## YouTube

| Format | Length | Notes |
|--------|--------|-------|
| Short | Under 60s | Vertical, no chapters |
| Standard | 8-20 min | Sweet spot for Arabic educational content |
| Long | 20-60 min | Podcast-style, interviews |
| Podcast | 45-90 min | High retention if strong guest |

**Title**: 55-60 characters
**Description**: First 150 chars are the meta — treat as headline

## Podcast (Audio)

| Format | Length | Notes |
|--------|--------|-------|
| Short-form | 10-20 min | News, daily briefing, tips |
| Standard | 30-45 min | Interviews, educational |
| Long-form | 60-90 min | Deep interviews, narrative |
| Avoid | 90+ min | Requires exceptional content to hold |

**Chapters**: Always — Arabic listeners use them
**Show notes**: 150 words max, Arabic, SEO-aware

## LinkedIn

| Format | Length | Notes |
|--------|--------|-------|
| Post | 150-300 words | Sweet spot for Arabic LinkedIn |
| Article | 800-1500 words | Less reach than posts currently |
| Video | 1-3 min | Native video > link to YouTube |

## X / Twitter

| Format | Length | Notes |
|--------|--------|-------|
| Single tweet | Max 280 chars | Hook must standalone |
| Thread | 5-10 tweets | Educational, analysis |
| Space | 30-60 min | Live audio — high engagement in Gulf |
