# Arabic Registers — Decision Guide

## The Three Registers

### 1. Modern Standard Arabic (الفصحى / MSA)
**Use for**: News, finance, government, formal education, B2B, legal
**Signals**: Authority, credibility, seriousness, formality
**Audience response**: Professional trust — but emotional distance
**Risk**: Can feel cold, bureaucratic, or inaccessible in casual contexts

### 2. Educated Colloquial (عامية مثقفة)
**Use for**: Podcasts, LinkedIn, professional personal brands, editorial content
**Definition**: Colloquial base with MSA vocabulary — sounds like an educated person speaking naturally
**Signals**: Approachable authority — smart but human
**Best for**: Most content in 2024 — hits the sweet spot

### 3. Regional Dialect (لهجة)
**Use for**: Entertainment, youth brands, food, lifestyle, local community content
**Signals**: Authenticity, belonging, cultural identity
**Risk**: Limits cross-regional reach unless Egyptian (which travels best)

---

## Register Decision Matrix

| Situation | Register |
|-----------|---------|
| Financial / legal content | MSA |
| News and current affairs | MSA |
| Educational documentary | MSA |
| Professional podcast | Educated Colloquial |
| LinkedIn thought leadership | MSA leaning |
| Instagram lifestyle | Dialect (audience-matched) |
| TikTok / Reels | Dialect or Educated Colloquial |
| Youth / Gen Z brand | Dialect |
| Luxury brand | MSA or Educated Colloquial |
| Food / Consumer | Dialect |
| Multi-regional audience | Educated Colloquial |

---

## Dialect Reach Map

```
Egyptian Arabic          ████████████████████  Widest cross-region reach
Gulf Arabic              ██████████████        Strong — especially in Gulf
Levantine Arabic         ████████████          Good — especially Levant/diaspora
Sudanese Arabic          ██████                Sudan + East Africa diaspora
North African (Darija)   ████                  Mostly local — limited elsewhere
```

---

## Code-Switching (المزج)

Some brands intentionally mix Arabic and English:
- **When it works**: Tech brands, startups, diaspora-targeting, Gen Z
- **When it fails**: Heritage brands, premium Arabic identity brands, government
- **Rule**: If you code-switch, do it intentionally — not because translation is hard

Examples:
- ✅ "ال content strategy بتاعتك" — intentional, casual, works for tech/media
- ❌ "نحن نقدم لكم أفضل الـ services" — lazy, not intentional, undermines credibility
