# Arabic Content Calendar — Key Dates & Timing

## High-Impact Annual Events

### Ramadan
- Timing: Shifts ~11 days earlier each Gregorian year
- Content behavior: Volume spikes massively; tone shifts to reflective/spiritual
- Best content: Personal stories, gratitude, community, brand values
- Avoid: Hard-sell, controversy, heavy entertainment
- Peak engagement: After Iftar (30 min after sunset) and after Taraweeh
- Platform peak: YouTube long-form, Instagram, TikTok
- Strategy: Plan 30-day content arc — not just the first week

### Eid Al-Fitr (end of Ramadan)
- Duration: 3 days official, 1 week content window
- Tone: Celebratory, generous, community-focused
- Content: Congratulations, reflection on Ramadan, new beginnings
- Brands: Gift-giving, offers — but lead with emotion, not discount

### Eid Al-Adha
- Duration: 4 days official, 1 week content window
- Tone: Sacrifice, family, generosity
- Context: Hajj season overlaps — content with pilgrim/spiritual angle performs
- Stronger in: Gulf, Egypt, Sudan

### Saudi National Day (September 23)
- Massive content moment in KSA and pan-Gulf
- Brands: Green/white palette, patriotic messaging
- Non-KSA brands: Optional to participate; feels forced unless authentic

### UAE National Day (December 2-3)
- Similar to Saudi National Day but UAE-specific
- Red/green/white/black palette
- Dubai/Abu Dhabi brands: mandatory; others optional

### New Year (Gregorian: January 1)
- Moderate engagement across Arab world
- Not as strong as in Western markets
- Better angle: reflection and goals than pure celebration

### New Year (Hijri)
- Lower commercial engagement but high for Islamic/spiritual content
- Opportunity for brands to show cultural awareness

## Regional Events

### Gulf
- National days (Saudi, UAE, Kuwait, Qatar, Bahrain, Oman) — patriotic content windows
- Summer: Lower engagement June-August (heat + travel)
- Winter: Peak content season October-March

### Egypt
- Revolution anniversary (January 25) — sensitive, avoid commercial content
- Sham El-Nessim (Easter Monday) — spring celebration, food-focused
- Summer: Alexandria content peaks

### Sudan
- Independence Day (January 1)
- Revolution anniversary (April 6 and December 19) — politically sensitive

## Weekly Patterns

| Day | Behavior |
|-----|---------|
| Thursday | Pre-weekend; highest social engagement; best for launches |
| Friday | Family/religious day; minimal commercial content; stories work |
| Saturday | Second-highest engagement; lifestyle and entertainment |
| Sunday | Start of work week in Gulf; professional content |

## Daily Peak Times (Gulf Standard Time, GMT+4)

| Platform | Peak Time |
|----------|-----------|
| Instagram | 7-9pm |
| TikTok | 8-10pm |
| X/Twitter | 9-11pm |
| YouTube | 9pm-midnight |
| LinkedIn | 8-10am Sunday-Thursday |

## Ramadan-Specific Daily Timing (Gulf)

- **Avoid posting**: 2-4pm (sleep time before Iftar)
- **Peak 1**: 30 min after Iftar (8-9pm approximately)
- **Peak 2**: After Taraweeh prayers (11pm-1am)
- **Peak 3**: Suhoor window (3-4:30am) — surprisingly active
