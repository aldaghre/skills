# Color Psychology — Logo Design Reference

## Core Colors with Arab Market Notes

| Color | Universal | Arab Market | Industries | Standout Shades |
|-------|-----------|-------------|-----------|-----------------|
| **Blue** | Trust, tech, corporate | Strong positive — finance, gov, tech | Fintech, healthcare, SaaS | Deep navy #0A1628, Electric cobalt #0057FF |
| **Green** | Growth, nature, health | Deeply tied to Islam — use intentionally | Wellness, food, Islamic brands | Deep forest #1A3C2A, Sage #87A878 |
| **Gold/Yellow** | Premium, energy | Gold = prestige, luxury, heritage (very strong) | Luxury, heritage, premium | Warm gold #C9A84C, Antique brass #B08D57 |
| **Red** | Energy, urgency | Positive — strength, celebration | Food, retail, sports | Deep crimson #8B0000, Vermillion #E34234 |
| **Black** | Luxury, authority | Premium — works for high-end brands | Luxury, consulting, legal | Always pair with warmth |
| **Purple** | Creative, spiritual | Less common = opportunity OR unfamiliarity | Beauty, wellness, education | Avoid in AI/tech — oversaturated globally |
| **Orange** | Energetic, friendly | Warm, approachable, consumer-facing | Food delivery, retail, youth | Burnt sienna #A0522D, Coral #FF6B47 |

## Arab Market Premium Signals

1. **Gold** (#C9A84C → #8B6914) — strongest premium signal in Arab markets
2. **Deep Navy** (#0A1628) — authority and trust
3. **Off-white / Cream** (#F5F0E8) — understated luxury
4. **Charcoal** (#2C2C2C) — sophisticated, modern premium

## Colors With Cultural Weight

- **Green**: Islamic connotation — use with awareness, not casually
- **Red + White + Black + Green**: Pan-Arab flag colors — patriotic associations
- **Pure yellow** without warmth: Can feel cheap in premium contexts

## Industry Color Opportunity Map

| Industry | What Everyone Uses | Opportunity |
|----------|-------------------|-------------|
| Fintech | Blue, dark navy | Warm tones, human feel |
| Food | Red, orange, green | Deep neutrals, sophisticated |
| Real Estate | Navy, grey, gold | Bold distinctive marks |
| Tech/SaaS | Blue, purple, gradient | Earth tones, analog feel |
| Media | Black, red | Soft editorial neutrals |
| Logistics | Blue, orange | Clean minimal precision |

## Proven Color Combination Formulas

**Anchor + Energy**: Deep neutral + one bold accent → professional, premium B2B
**Monochrome + Texture**: Single color in tones → sophisticated, editorial, luxury
**Analogous Warmth**: Two adjacent warm colors → food, lifestyle, Arabic heritage
**High Contrast**: Black/white + one saturated color → modern tech, media
**Earth + Pop**: Neutral base + unexpected neon/electric → creative, startup, Gen Z
