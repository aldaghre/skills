# Logo Types — Taxonomy & Decision Guide

## The 7 Types

| Type | Description | Best For | Risk |
|------|-------------|---------|------|
| **Wordmark** | Brand name only, custom type | Short distinctive names | Font choice IS the logo |
| **Lettermark** | Initials only (1-3 letters) | Long names, meaningful initials | Needs high distinctiveness |
| **Pictorial Mark** | Standalone icon, no text | Established brands | Needs time to build recognition |
| **Abstract Mark** | Geometric/abstract shape | Brands conveying feeling over literal meaning | Hard to do distinctively |
| **Combination Mark** | Symbol + wordmark | New brands needing both icon + name clarity | Most flexible — recommended default |
| **Emblem** | Text inside shape/badge | Heritage, institutions, sports, clubs | Complex — doesn't scale small |
| **Mascot/Character** | Illustrated character | Consumer, food, entertainment | Can date quickly |

## Decision Matrix

| Scenario | Recommended |
|----------|------------|
| New brand, needs recognition fast | Combination Mark |
| Short, distinctive name | Wordmark |
| Long brand name | Lettermark or Combination |
| Heritage / traditional | Emblem or Calligraphy Wordmark |
| Premium / luxury | Wordmark or Abstract Mark |
| Tech / SaaS startup | Abstract or Combination |
| Arabic/Islamic audience | Geometric Abstract or Calligraphy Wordmark |
| Global, multi-language | Abstract Mark (language-agnostic) |

## Scalability Test (Non-Negotiable)

Test every logo at: 1000px / 200px / 64px / 32px / 16px

If it fails at 32px → too complex. Simplify.
Rule: must be recognizable reproduced as a rubber stamp.

## Timeless vs Trendy

### Timeless
- Geometric precision
- Fewer than 3 colors
- No gradients in primary mark
- No drop shadows or embossing
- Works in black and white

### Trend Red Flags (2024-2025)
- Gradient-heavy marks
- Overly thin letterforms
- Too many paths in the icon
- Generic "tech" hexagons or circuit boards
- Generic "Arab" clichés: crescent + star without conceptual reason
- Arabesque decoration as the only Arabic signal
