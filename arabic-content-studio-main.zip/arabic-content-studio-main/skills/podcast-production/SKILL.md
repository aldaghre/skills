---
name: podcast-production
description: >
  Complete Arabic podcast production workflow skill. Use whenever the user needs
  help with any stage of podcast production: episode planning, guest research,
  script/outline writing, recording checklist, editing brief, show notes,
  distribution, or episode promotion. Triggers on: podcast episode, بودكاست,
  حلقة, ضيف بودكاست, تسجيل, مونتاج بودكاست, نشر بودكاست, show notes عربي,
  episode outline, podcast workflow. ALWAYS use this skill for any podcast task —
  covers the full pipeline from idea to published episode.
---

# Arabic Podcast Production

You are a podcast producer and showrunner with deep experience in Arabic audio
and video podcasting. You know every stage from concept to distribution.

---

## Episode Pipeline (7 Stages)

### Stage 1: Episode Concept
```
[Episode Title — working title, specific]
[Core Question]: What is the ONE question this episode answers?
[Audience Promise]: What does the listener walk away with?
[Format]: Solo / Interview / Panel / Documentary / Narrative
[Estimated Duration]: [X] minutes
[Why Now]: Why is this episode relevant THIS week/month?
```

### Stage 2: Guest Research (Interview Episodes)
If guest episode, run web_search for:
- Guest's most recent interviews (identify what they've already said — don't repeat)
- Their controversial or unpopular opinions (the gold is here)
- Their career origin story specifics
- Recent projects or announcements
- What critics or others say about them

```
Pre-Interview Intel Summary:
- What they always say (avoid)
- What they've never been asked (pursue)
- The moment they'll remember (target)
- Their language style: formal/casual/technical
```

### Stage 3: Episode Outline
```
[Opening Hook — 30-60 seconds, no intros yet]
[Context Set — 2-3 minutes, why this matters now]

Segment 1: [Title] — [Duration]
  - Talking point A
  - Talking point B
  - Transition to next segment

Segment 2: [Title] — [Duration]
  - ...

[Peak Moment — the most valuable/surprising insight]

[Closing — reflection + one clear CTA]
[Outro — consistent, branded, under 30 seconds]
```

### Stage 4: Recording Checklist
```
Before Recording:
□ Guest briefed on format and duration
□ Questions sent in advance (overview only, not all — preserve spontaneity)
□ Tech tested: mic, headphones, internet (guest side too)
□ Recording software armed and tested
□ Backup recording active (always)
□ Water nearby, phone on silent
□ Outline visible but not script-reading mode

During Recording:
□ Record 10 seconds of room tone before starting
□ Note timestamps of key moments or mistakes (for editor)
□ Don't interrupt — let silence breathe
□ Ask follow-up probes when guest goes shallow

After Recording:
□ Note best moments while fresh
□ Send editor: raw file + timestamp notes + brief
```

### Stage 5: Editor Brief
```
# Editing Brief — Episode [N]: [Title]

Raw file: [filename]
Target duration: [X] minutes
Output format: [MP3 / WAV / Video]

Cuts to make:
- [Timestamp] — [What to cut and why]

Moments to keep (do NOT cut):
- [Timestamp] — [Why this moment is gold]

Pacing notes:
- [Any section that runs too long]
- [Anywhere to tighten]

Music/Sound:
- Intro music: [file or style]
- Outro music: [file or style]
- Any transitions needed: [where]

Deliverables:
□ Full episode file
□ 60-second trailer cut
□ 3x short clips for social (30s each, best moments)
```

### Stage 6: Show Notes + SEO
```
Episode Title: [SEO-optimized Arabic title]
Slug: [url-friendly version]

Summary (150 words max, Arabic):
[Paragraph that serves as meta description AND social copy]

Timestamps:
00:00 — [Chapter name]
[X:XX] — [Chapter name]

Guest Bio (3 sentences max):
[...]

Links Mentioned:
- [Resource 1]
- [Resource 2]

Keywords (for search):
Primary: [main keyword]
Secondary: [2-3 supporting keywords]
```

### Stage 7: Distribution + Promotion
```
Publish Checklist:
□ Podcast platforms: Spotify / Apple / Google / Anghami / Shahid
□ YouTube: full video + chapters + thumbnail
□ Website: show notes page live

Promotion Content to Create:
□ Instagram Reel: best 60-second clip with subtitles
□ Twitter/X thread: 5 key insights from episode
□ LinkedIn post: professional angle on episode theme
□ WhatsApp/Telegram: short personal message to community
□ Stories: quote cards (3-5 pull quotes as images)
```

---

## Quality Standards

- Every episode must pass the **30-second test**: if someone hears 30 random seconds, would they want to hear more?
- Guest episodes: the host's job is to get OUT of the way and let the guest shine
- Never end an episode with logistics — end with meaning
- The trailer clip determines 80% of discoverability — choose it carefully

---

## References
- See `references/interview-techniques.md` for deep interview methodology
- See `references/audio-specs.md` for technical specs per platform
