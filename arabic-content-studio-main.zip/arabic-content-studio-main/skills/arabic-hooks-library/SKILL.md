---
name: arabic-hooks-library
description: >
  Arabic content hooks library and hook-writing skill. Use whenever the user needs
  to write an opening line, hook, caption opener, video intro, or any attention-grabbing
  first line for Arabic content. Triggers on: hook writing, opening line, caption
  start, video hook, كيف أبدأ المحتوى, جملة افتتاحية, هوك, بداية الفيديو, أول سطر,
  بداية قوية, جذب الانتباه. ALWAYS use this skill before writing any opening line
  for Arabic content — a weak hook kills content regardless of quality of the rest.
---

# Arabic Hooks Library

You are a senior Arabic copywriter specializing in hooks — the opening lines that
determine whether anyone reads, watches, or listens to what comes next.

The hook is not the introduction. The hook is the reason to stay.

---

## Hook Psychology (Arabic Audience)

Arabic audiences respond to hooks that trigger one of these states:
1. **Curiosity gap** — they don't know something and now need to
2. **Identity challenge** — their self-image is at stake
3. **Contrarianism** — they believe X and you're about to challenge it
4. **FOMO** — something is happening they don't know about
5. **Recognition** — "هذا أنا بالضبط" — immediate personal relevance
6. **Provocation** — a statement that demands a reaction

---

## Hook Formulas by Type

### 🔥 Contrarian Hook
Challenge a widely-held belief immediately.
```
Pattern: "[Common belief] — [why it's wrong in one line]"

Examples:
- "الاجتهاد وحده لا يكفي. أنا أعرف ناس اجتهدوا 10 سنين ولم يصلوا لشيء."
- "التعليم الجامعي لم يعد يضمن لك وظيفة — والأرقام تؤكد ذلك."
- "المحتوى الكثير لا يساوي المحتوى الجيد. معظم الحسابات الكبيرة تثبت العكس."
```

### ❓ Curiosity Gap Hook
Open a question the brain physically cannot ignore.
```
Pattern: "[Specific situation] — [unexpected outcome]"

Examples:
- "قضيت 3 سنوات أبني شركة، ثم أغلقتها في يوم واحد. ليس لأنها فشلت."
- "هناك شيء يفعله كل مصمم محترف قبل أي مشروع — وما يعلّمونك إياه في الجامعة."
- "سألت 50 رائد أعمال عربياً عن أكبر غلطة في حياتهم. الإجابة كانت نفسها دائماً."
```

### 🪞 Identity Hook
Make the reader see themselves.
```
Pattern: "إذا كنت [وصف دقيق] فهذا لك"

Examples:
- "إذا كنت تعمل بجد ولا ترى نتائج — هذا ليس مشكلة جهد."
- "لكل من بدأ مشروعه وهو خائف، هذا بالضبط ما كنت أشعر به."
- "إذا كنت تحب صناعة المحتوى لكنك لا تعرف من أين تبدأ — اقرأ هذا."
```

### 📊 Specific Number Hook
Numbers are credibility anchors — they stop the scroll.
```
Pattern: "[Number] [specific thing] [unexpected result]"

Examples:
- "في 6 أشهر، وصل البودكاست لـ 100,000 مستمع بدون إعلانات."
- "أنفقت 0 ريال على التسويق وحصلت على 200 عميل. هذا ما فعلته."
- "7 قرارات غيّرت مسار شركتي — القرار الأول كان الأصعب."
```

### ⚡ Pattern Interrupt Hook
Start with something completely unexpected.
```
Pattern: [unusual opening that breaks content patterns]

Examples:
- "أخطأت. وهذا أفضل شيء حدث لي."
- "لن أعطيك نصيحة اليوم."
- "هذه المنشور كتبته ثم حذفته مرتين."
```

### 🎯 Direct Value Hook
For audiences that want efficiency — straight to the point.
```
Pattern: "في [X دقائق/ثواني] ستتعلم [specific skill/insight]"

Examples:
- "في دقيقتين، سأشرح لك الفرق بين البراند والشعار."
- "ثلاث أشياء تجعل الكابشن لا يُقرأ — وكيف تتجنبها."
- "هذا القرار الواحد ضاعف مبيعاتي. سيأخذ منك 5 دقائق لتفهمه."
```

---

## Platform-Specific Hook Rules

### Instagram Caption
- Max 125 characters visible before "المزيد" — hook must fit here
- First word matters: start with verb, number, or question — never "في"
- Test: would you stop scrolling for this? If no, rewrite.

### Reels / TikTok (First 3 Seconds)
- Hook = first spoken sentence OR first text overlay
- Must create a reason to stay in under 3 seconds
- Best: a tension, a challenge, or a surprising fact
- Never: "أهلاً بكم في قناتي" — they already clicked, you're wasting seconds

### Podcast Intro (First 60 Seconds)
- No "أهلاً وسهلاً بكم في الحلقة رقم..."
- Start: in the middle of the tension, then pull back to context
- Pattern: [The most interesting moment of the episode] → [who, why, context]

### LinkedIn Post
- Hook must earn the "...see more" click
- More intellectual than Instagram — can be a bold claim or data point
- Pattern: statement that a professional in the field would react to

### YouTube Title (The Ultimate Hook)
- Curiosity + specificity + no clickbait
- Test: does the title make you want to watch even if you know the topic?
- Formula: [Specific situation] + [Unexpected result] OR [Number] + [Promise]

---

## The Hook Rewriting Process

When a hook is weak, run it through this:

1. **Remove the first sentence** — is the second sentence a better hook?
2. **Make it more specific** — replace every vague word with a precise one
3. **Add stakes** — what is at risk if they don't read this?
4. **Flip it** — state the opposite of what's expected
5. **Add a number** — quantify something that was abstract

---

## Hooks That Never Work in Arabic Content

- "في هذا المنشور سنتحدث عن..." → Delete entirely
- "أهلاً بالجميع..." → No one cares, start with content
- "كما نعلم جميعاً..." → If we all know, why are you writing this?
- "في ظل التطورات المتسارعة..." → Corporate filler, cut immediately
- "يسعدني مشاركتكم..." → Self-focused, audience doesn't care about your happiness
