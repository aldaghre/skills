---
name: New Skill Request
about: Propose a new skill for the Arabic Content Studio
title: '[SKILL] '
labels: 'new-skill'
---

## What should this skill do?
<!-- One sentence description -->

## When should it trigger?
<!-- What user phrases or contexts should activate it? -->

## What professional knowledge would it encode?
<!-- Not generic — what specific expertise should it contain? -->

## Why is this missing from the current skill set?
<!-- Gap it fills -->
