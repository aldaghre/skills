# 🎙️ Arabic Content Studio — Claude Skills Pack

> A professional skill library for Claude, purpose-built for Arabic content teams.
> Research-backed. Production-ready. No generic AI output.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Skills](https://img.shields.io/badge/Skills-8-blue.svg)]()
[![Arabic](https://img.shields.io/badge/Language-Arabic-green.svg)]()

---

## What This Is

A set of **Claude Skills** that give Claude deep expertise in Arabic content production.
Not generic "write in Arabic" prompts — these encode professional workflows, cultural intelligence, and platform-specific knowledge.

Built for Arabic media companies, content studios, and creators who want Claude to operate like a senior Arabic content team.

---

## Skills Index

| Skill | What It Does |
|-------|-------------|
| [`arabic-content-producer`](./skills/arabic-content-producer/) | Scripts, podcasts, Reels, articles with professional quality rules |
| [`arabic-culture-guide`](./skills/arabic-culture-guide/) | Dialect map, regional intelligence, cultural sensitivities |
| [`arabic-brand-voice`](./skills/arabic-brand-voice/) | Brand tone, style guides, editorial voice calibration |
| [`arabic-seo-distributor`](./skills/arabic-seo-distributor/) | Arabic SEO, hashtags, platform strategy per channel |
| [`arabic-hooks-library`](./skills/arabic-hooks-library/) | Hook formulas, opening lines, attention-grabbing copy |
| [`logo-designer`](./skills/logo-designer/) | Research → Concept → SVG → AI Prompts → Design Brief |
| [`podcast-production`](./skills/podcast-production/) | Full episode workflow: prep → structure → edit → publish |
| [`content-repurposing`](./skills/content-repurposing/) | 1 asset → 8+ formats across all platforms |

---

## Quick Start

### Claude Desktop
1. Clone this repo
   ```bash
   git clone https://github.com/smeseik-ai/arabic-content-studio.git
   ```
2. Open **Claude Desktop → Settings → Skills**
3. Add path to any skill folder, e.g. `./skills/arabic-content-producer`
4. Claude uses the skill automatically when relevant

### Claude.ai Project
Copy any `SKILL.md` contents into your Claude project's custom instructions.

### Claude Code
```bash
git clone https://github.com/smeseik-ai/arabic-content-studio.git
# Reference the skills/ directory in your project
```

---

## Repo Structure

```
arabic-content-studio/
├── README.md
├── skills/
│   ├── arabic-content-producer/
│   │   ├── SKILL.md
│   │   └── references/
│   │       ├── arabic-registers.md
│   │       └── platform-formats.md
│   ├── arabic-culture-guide/
│   │   ├── SKILL.md
│   │   └── references/
│   │       └── cultural-calendar.md
│   ├── arabic-brand-voice/
│   │   └── SKILL.md
│   ├── arabic-seo-distributor/
│   │   └── SKILL.md
│   ├── arabic-hooks-library/
│   │   └── SKILL.md
│   ├── logo-designer/
│   │   ├── SKILL.md
│   │   └── references/
│   │       ├── color-psychology.md
│   │       └── logo-types.md
│   ├── podcast-production/
│   │   └── SKILL.md
│   └── content-repurposing/
│       └── SKILL.md
├── docs/
│   └── how-to-add-skills.md
└── .github/
    └── ISSUE_TEMPLATE/
        └── new-skill.md
```

---

## Philosophy

These skills are **opinionated**. They encode real professional knowledge:
- Register differences between MSA and Arabic dialects
- Platform algorithm behavior for Arabic content
- Cultural sensitivities by region
- Content formats that actually perform in Arab markets

Generic prompts produce generic output. These skills produce professional output.

---

## Contributing

PRs welcome. See [`docs/how-to-add-skills.md`](./docs/how-to-add-skills.md).
Every skill must contain real professional knowledge — no filler.

---

## License

MIT — free to use, modify, and distribute.

---

*Built with [Anthropic Claude Skills](https://docs.claude.ai) · Made for Arabic content teams*
