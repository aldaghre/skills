# How to Add a Skill

## Skill Structure

```
skills/
└── your-skill-name/
    ├── SKILL.md          ← Required
    └── references/       ← Optional supporting files
        ├── topic-one.md
        └── topic-two.md
```

## SKILL.md Format

```markdown
---
name: skill-name-in-kebab-case
description: >
  One paragraph. Who you are as an expert.
  ALL triggers: exact phrases, contexts, Arabic keywords, use cases.
  Be specific and "pushy" — don't undersell when Claude should use this skill.
---

# Skill Title

[Expert role statement]

---

## Core Principles / Framework

## Output Formats or Workflows

## Quality Rules

## References
- See `references/file.md` for [what it contains]
```

## Quality Standard

A skill is ready when it meets ALL of these:

1. **Real knowledge** — not generic prompting. Contains specifics a human expert would know.
2. **Triggerable** — description specific enough that Claude uses it at the right moment.
3. **Better output** — following it produces measurably better output than without it.
4. **No filler** — every line earns its place.

## Submitting a PR

1. Fork the repo
2. Create your skill folder under `skills/`
3. Follow the structure above
4. Add your skill to the table in `README.md`
5. PR description: 2-3 sentences — what it does and why it's needed
